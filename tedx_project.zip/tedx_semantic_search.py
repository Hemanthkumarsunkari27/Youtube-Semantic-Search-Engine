
# Your entire working Colab code goes here
# Copy-paste from your working cell
